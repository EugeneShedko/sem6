/*____________________________________________________________________________
	Copyright (C) 1997 Network Associates, Inc. and its affiliates.
	All rights reserved.
	
	

	PGPPlugTypes.h,v 1.2 1997/10/22 23:05:55 elrod Exp
____________________________________________________________________________*/

#ifndef Included_PGPPlugTypes_h	/* [ */
#define Included_PGPPlugTypes_h


typedef	long	PluginError; 

#endif /* ] Included_PGPPlugTypes_h */


/*__Editor_settings____

	Local Variables:
	tab-width: 4
	End:
	vi: ts=4 sw=4
	vim: si
_____________________*/

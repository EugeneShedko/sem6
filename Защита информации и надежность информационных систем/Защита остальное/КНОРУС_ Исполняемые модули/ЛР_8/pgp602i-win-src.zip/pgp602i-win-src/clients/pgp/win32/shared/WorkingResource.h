//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by Working.rc
//
#define IDS_WORKINGENCRYPT              9701
#define IDS_WORKINGSIGN                 9702
#define IDS_WORKINGENCRYPTSIGN          9703
#define IDS_WORKINGDECRYPT              9704
#define IDS_WORKINGTRANSFER             9705
#define IDD_WORKING                     9991
#define IDC_PROGRESS                    9992
#define IDC_PROGRESS_TEXT               9993

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

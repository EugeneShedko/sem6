/*____________________________________________________________________________
	Copyright (C) 1997 Network Associates, Inc. and its affiliates.
	All rights reserved.
	
	

	DisplayMessage.h,v 1.3 1997/07/21 06:03:27 elrod Exp
____________________________________________________________________________*/
#ifndef Included_DisplayMessage_h	/* [ */
#define Included_DisplayMessage_h

#ifdef __cplusplus
extern "C" {
#endif

int DisplayMessage(HWND hwnd, long StringId, long TitleId, UINT buttons);


#ifdef __cplusplus
}
#endif



#endif /* ] Included_DisplayMessage_h */


/*__Editor_settings____

	Local Variables:
	tab-width: 4
	End:
	vi: ts=4 sw=4
	vim: si
_____________________*/

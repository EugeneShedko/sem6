//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by PGPtools.rc
//
#define IDS_SELFILEENC                  1
#define IDS_SELFILESIGN                 2
#define IDS_SELFILEENCSIGN              3
#define IDS_ALLFILES                    4
#define IDS_SELFILEDECVER               5
#define IDS_PGPFILES                    6
#define IDS_SELFILEWIPE                 7
#define IDS_SELFILEADD                  8
#define IDS_KEYFILES                    9
#define IDS_NOVOLWIPENT                 10
#define IDS_PGPERROR                    11
#define IDI_TOOLSICO                    101
#define IDI_KEYS                        102
#define IDI_ENCRYPT                     103
#define IDI_SIGN                        104
#define IDI_ENCSIGN                     105
#define IDI_DECRYPT                     106
#define IDI_WIPE                        107
#define IDD_CUST32DLG                   109
#define IDD_CUST16DLG                   110
#define IDD_EXPCLIPCHILD                111
#define IDR_PGPTOOLSMENU                116
#define IDR_ACCELERATOR1                117
#define IDC_KEYS                        201
#define IDC_ENCRYPT                     202
#define IDC_SIGN                        203
#define IDC_ENCSIGN                     204
#define IDC_DECRYPT                     205
#define IDC_WIPE                        206
#define IDC_FREESPACE_WIPE              207
#define IDC_QUIT                        208
#define IDC_ADDKEY                      209
#define IDI_SMENC                       209
#define IDI_SMSIGN                      210
#define IDI_SMENCSIG                    211
#define IDI_SMKEYS                      212
#define IDI_SMDEC                       213
#define IDI_SMWIPE                      214
#define IDI_L4KEY                       218
#define IDI_L4KEYS                      218
#define IDI_L8KEYS                      220
#define IDI_S4KEYS                      221
#define IDI_L4WIPE                      222
#define IDI_S8WIPE                      223
#define IDI_L8WIPE                      224
#define IDI_S4WIPE                      225
#define IDI_L8ENC                       226
#define IDI_L4ENC                       227
#define IDI_L8SIG                       228
#define IDI_L4SIG                       229
#define IDI_L8DECVER                    230
#define IDI_L4DECVER                    231
#define IDI_L8ENCSIG                    232
#define IDI_L4ENCSIG                    234
#define IDI_S8ENCSIG                    235
#define IDI_S4ENCSIG                    236
#define IDI_S8ENC                       237
#define IDI_S4ENC                       238
#define IDI_S8SIG                       239
#define IDI_S4SIG                       240
#define IDI_S8DECVER                    241
#define IDI_S4DECVER                    242
#define IDI_S8KEYS                      243
#define IDI_L4WIPEV                     244
#define IDI_S4WIPEV                     245
#define IDI_L8WIPEV                     246
#define IDI_S8WIPEV                     247
#define IDC_PGPPREFS                    400
#define IDC_EDITCLIP                    401
#define IDC_ASSOCVIEWER                 402
#define IDC_HELPTOPICS                  403
#define IDC_ABOUTPGP                    404
#define IDC_ASSOCVIEW                   405
#define IDC_RESIZE                      407
#define IDC_CLIPBOARD                   1000

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        244
#define _APS_NEXT_COMMAND_VALUE         408
#define _APS_NEXT_CONTROL_VALUE         1004
#define _APS_NEXT_SYMED_VALUE           308
#endif
#endif

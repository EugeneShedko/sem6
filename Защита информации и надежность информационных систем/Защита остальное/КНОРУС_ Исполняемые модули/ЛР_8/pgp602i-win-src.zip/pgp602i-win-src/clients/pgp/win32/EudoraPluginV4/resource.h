//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by PGPplugin.rc
//
#define IDS_WARN_NORECIPIENTS           1
#define IDS_WARN_NORECIPIENTSTITLE      2
#define IDS_TITLE_RECIPIENTDIALOG       3
#define IDS_WARN_DECRYPTFAILED          4
#define IDS_TITLE_PGPERROR              5
#define IDS_SUCCESS_ADDKEY              6
#define IDS_TITLE_ADDKEY                7
#define IDS_WARN_ADDKEY                 8
#define IDS_STRING8                     8
#define IDS_STRING9                     9
#define IDS_TOOLTIP1                    10
#define IDS_TOOLTIP2                    11
#define IDS_TOOLTIP3                    12
#define IDS_TOOLTIP4                    13
#define IDS_TOOLTIP5                    14
#define IDS_TOOLTIP6                    15
#define IDS_TOOLTIP7                    16
#define IDS_TOOLTIP8                    17
#define IDS_E_EXPIRED                   18
#define IDS_E_EXPIREDTITLE              19
#define IDS_PGPKEYSEXE                  20
#define IDS_E_LAUNCHPGPKEYS             21
#define IDS_EXE                         22
#define IDS_DLL                         23
#define IDI_PGP32                       101
#define IDI_PGP_ENCRYPT                 103
#define IDI_PGP_DECRYPT                 104
#define IDI_PGP_ENCRYPT_SIGN            105
#define IDI_PGP_SIGN                    106
#define IDI_PGP_VERIFY                  107
#define IDI_PGP_ADDKEY                  108
#define IDM_PGPABOUTMENU                113
#define IDM_PGPMENU                     114
#define IDM_PGPENCRYPTMENU              114
#define IDM_PGPDECRYPTMENU              115
#define IDI_PGP_KEYS                    125
#define IDB_READTOOLBAR                 161
#define IDB_SENDTOOLBAR                 162
#define IDD_PASSPHRASE                  1001
#define IDC_PHRASE                      1002
#define IDC_HIDETYPING                  1003
#define IDC_PROMPTSTRING                1004
#define ID_PGPHELP                      60001
#define ID_ABOUTPGP                     60002
#define ID_PGPENCRYPT                   60003
#define ID_PGPSIGN                      60004
#define ID_PGPENCRYPTSIGN               60005
#define ID_PREFERENCES                  60006
#define ID_PGPDECRYPTVERIFY             60007
#define ID_PGPGETKEY                    60008
#define ID_PGPKEYS                      60009

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        127
#define _APS_NEXT_COMMAND_VALUE         60010
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

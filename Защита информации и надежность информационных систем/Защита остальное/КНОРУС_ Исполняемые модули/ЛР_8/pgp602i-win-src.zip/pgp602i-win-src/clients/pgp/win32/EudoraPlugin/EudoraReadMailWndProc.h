/*____________________________________________________________________________
	Copyright (C) 1997 Network Associates, Inc. and its affiliates.
	All rights reserved.
	
	

	EudoraReadMailWndProc.h,v 1.3 1997/10/22 23:05:51 elrod Exp
____________________________________________________________________________*/

#ifndef Included_EudoraReadMailWndProc_h	/* [ */
#define Included_EudoraReadMailWndProc_h

LRESULT WINAPI EudoraReadMailWndProc(HWND hwnd, 
									 UINT msg, 
									 WPARAM wParam, 
									 LPARAM lParam);

#endif /* ] Included_EudoraReadMailWndProc_h */


/*__Editor_settings____

	Local Variables:
	tab-width: 4
	End:
	vi: ts=4 sw=4
	vim: si
_____________________*/

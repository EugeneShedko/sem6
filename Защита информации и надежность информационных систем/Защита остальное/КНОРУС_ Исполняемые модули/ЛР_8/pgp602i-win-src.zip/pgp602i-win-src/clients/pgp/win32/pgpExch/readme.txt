PGP Plugin for Exchange
-----------------------

INSTALLATION

1) Copy the file "pgpExch.dll" to your Windows\System or WINNT35\SYSTEM32 directory
2) Double-click on the file "pgpExch.reg" to set the proper Registry settings

Send comments to dgal@pgp.com

- Damon Gallaty


/*____________________________________________________________________________
	Copyright (C) 1997 Network Associates, Inc. and its affiliates.
	All rights reserved.
	
	

	SendMailToolbarWndProc.h,v 1.3 1997/10/22 23:05:57 elrod Exp
____________________________________________________________________________*/

#ifndef Included_SendMailToolbarWndProc_h	/* [ */
#define Included_SendMailToolbarWndProc_h


LRESULT WINAPI SendMailToolbarWndProc(HWND hwnd, 
									  UINT msg, 
									  WPARAM wParam, 
									  LPARAM lParam);

#endif /* ] Included_SendMailToolbarWndProc_h */


/*__Editor_settings____

	Local Variables:
	tab-width: 4
	End:
	vi: ts=4 sw=4
	vim: si
_____________________*/

//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SharedStrings.rc
//
#define IDS_PASSPHRASEPROMPT            9501
#define IDS_PASSPHRASEREENTER           9502
#define IDS_CONVPASSPHRASE              9503
#define IDS_SIGSTATUS                   9504
#define IDS_ALGNOTSUPPORTED             9505
#define IDS_GOODSIG                     9506
#define IDS_BADSIG                      9507
#define IDS_UNKNOWNSIG                  9508
#define IDS_SIGNER                      9509
#define IDS_UNKNOWNSIGNER               9510
#define IDS_REVOKEDKEY                  9511
#define IDS_EXPIREDKEY                  9512
#define IDS_DISABLEDKEY                 9513
#define IDS_INVALIDKEY                  9514
#define IDS_SIGDATE                     9515
#define IDS_VERIFIED                    9516
#define IDS_BEGINDECRYPTED              9517
#define IDS_ENDDECRYPTED                9518
#define IDS_BEGINVERIFIED               9519
#define IDS_ENDVERIFIED                 9520

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

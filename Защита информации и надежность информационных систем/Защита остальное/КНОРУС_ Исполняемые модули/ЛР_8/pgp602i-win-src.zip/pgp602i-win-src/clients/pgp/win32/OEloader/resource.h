//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by msimn.rc
//
#define IDS_TITLE                       1
#define IDS_NOPLUGIN                    2
#define IDS_NOMSIMN                     3
#define IDS_BADINSTALL                  4
#define IDI_MSIMN                       2
#define IDI_NEWS                        3
#define IDI_ENVELOPE                    4
#define IDI_LETTER                      5
#define IDI_PACKAGE                     6

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        108
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif

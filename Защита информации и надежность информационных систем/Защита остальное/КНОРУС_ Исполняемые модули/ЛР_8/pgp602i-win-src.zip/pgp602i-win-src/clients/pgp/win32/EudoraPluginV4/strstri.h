/*
** Copyright (C)1997 Network Associates, Inc. and its affiliates.
** All rights reserved.
*/

#ifdef __cplusplus
extern "C" {
#endif

char* strstri(char * inBuffer, char * inSearchStr);

#ifdef __cplusplus
}
#endif

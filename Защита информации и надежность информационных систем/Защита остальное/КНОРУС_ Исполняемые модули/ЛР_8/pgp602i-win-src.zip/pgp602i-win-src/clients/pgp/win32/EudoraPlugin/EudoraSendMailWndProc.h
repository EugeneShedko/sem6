/*____________________________________________________________________________
	Copyright (C) 1997 Network Associates, Inc. and its affiliates.
	All rights reserved.
	
	

	EudoraSendMailWndProc.h,v 1.3 1997/10/22 23:05:51 elrod Exp
____________________________________________________________________________*/

#ifndef Included_EudoraSendMailWndProc_h	/* [ */
#define Included_EudoraSendMailWndProc_h


LRESULT 
WINAPI 
EudoraSendMailWndProc(HWND hwnd, 
					  UINT msg, 
					  WPARAM wParam, 
					  LPARAM lParam);

#endif /* ] Included_EudoraSendMailWndProc_h */


/*__Editor_settings____

	Local Variables:
	tab-width: 4
	End:
	vi: ts=4 sw=4
	vim: si
_____________________*/

/*____________________________________________________________________________
	Copyright (C) 1997 Network Associates, Inc. and its affiliates.
	All rights reserved.
	
	

	$Id: CreateWiz.h,v 1.2.16.1 1998/11/12 03:13:05 heller Exp $
____________________________________________________________________________*/
#ifndef Included_CreateWiz_h	/* [ */
#define Included_CreateWiz_h

void CreateWiz(HWND hwndMain);

#endif /* ] Included_CreateWiz_h */


/*__Editor_settings____

	Local Variables:
	tab-width: 4
	End:
	vi: ts=4 sw=4
	vim: si
_____________________*/

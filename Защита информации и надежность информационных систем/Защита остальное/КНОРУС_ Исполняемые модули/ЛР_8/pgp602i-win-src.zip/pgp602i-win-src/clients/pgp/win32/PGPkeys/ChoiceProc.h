/*____________________________________________________________________________
	Copyright (C) 1998 Network Associates, Inc.
	All rights reserved.
	
	$Id: ChoiceProc.h,v 1.3 1998/08/11 15:19:59 pbj Exp $
____________________________________________________________________________*/
#ifndef _CHOICEPROC_H
#define _CHOICEPROC_H


BOOL 
CALLBACK 
ChoiceProc(	HWND hwnd, 
			UINT msg, 
			WPARAM wParam, 
			LPARAM lParam );

#endif
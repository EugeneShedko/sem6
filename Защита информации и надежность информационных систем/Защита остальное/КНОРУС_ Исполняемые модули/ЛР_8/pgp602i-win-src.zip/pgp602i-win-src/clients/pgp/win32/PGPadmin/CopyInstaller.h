/*____________________________________________________________________________
	Copyright (C) 1997 Network Associates, Inc. and its affiliates.
	All rights reserved.
	
	

	$Id: CopyInstaller.h,v 1.2.18.1 1998/11/12 03:13:03 heller Exp $
____________________________________________________________________________*/
#ifndef Included_CopyInstaller_h	/* [ */
#define Included_CopyInstaller_h

DWORD CopyInstaller(HWND hwnd, char *szClientInstaller, char *szInstallDir);

#endif /* ] Included_CopyInstaller_h */


/*__Editor_settings____

	Local Variables:
	tab-width: 4
	End:
	vi: ts=4 sw=4
	vim: si
_____________________*/

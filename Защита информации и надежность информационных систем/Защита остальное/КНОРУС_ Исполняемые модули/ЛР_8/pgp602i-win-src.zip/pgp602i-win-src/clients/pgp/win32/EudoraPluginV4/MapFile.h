/*____________________________________________________________________________
	Copyright (C) 1997 Network Associates, Inc. and its affiliates.
	All rights reserved.
	
	

	$Id: MapFile.h,v 1.2.8.1 1998/11/12 03:11:47 heller Exp $
____________________________________________________________________________*/
#ifndef Included_MapFile_h	/* [ */
#define Included_MapFile_h


#ifdef __cplusplus
extern "C" {
#endif

char* MapFile(const char* Path, DWORD* FileSize);


#ifdef __cplusplus
}
#endif

#endif /* ] Included_MapFile_h */


/*__Editor_settings____

	Local Variables:
	tab-width: 4
	End:
	vi: ts=4 sw=4
	vim: si
_____________________*/



/*____________________________________________________________________________
	Copyright (C) 1997 Network Associates, Inc. and its affiliates.
	All rights reserved.
	
	

	$Id: FindInstaller.h,v 1.1.18.1 1998/11/12 03:13:07 heller Exp $
____________________________________________________________________________*/
#ifndef Included_FindInstaller_h	/* [ */
#define Included_FindInstaller_h

BOOL CALLBACK FindInstallerDlgProc(HWND hwndDlg, 
								   UINT uMsg, 
								   WPARAM wParam, 
								   LPARAM lParam);

#endif /* ] Included_FindInstaller_h */


/*__Editor_settings____

	Local Variables:
	tab-width: 4
	End:
	vi: ts=4 sw=4
	vim: si
_____________________*/

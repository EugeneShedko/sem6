/*____________________________________________________________________________
	Copyright (C) 1997 Network Associates, Inc. and its affiliates.
	All rights reserved.
	
	

	$Id: pgpVersionHeader.h,v 1.2.8.1 1998/11/12 03:11:16 heller Exp $
____________________________________________________________________________*/
#ifndef Included_pgpVersionHeader_h	/* [ */
#define Included_pgpVersionHeader_h


extern const char  pgpVersionHeaderString[];

#endif /* ] Included_pgpVersionHeader_h */


/*__Editor_settings____

	Local Variables:
	tab-width: 4
	End:
	vi: ts=4 sw=4
	vim: si
_____________________*/
